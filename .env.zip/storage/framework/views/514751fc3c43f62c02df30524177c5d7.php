<?php $__env->startSection('crumbs'); ?><a href="<?php echo e($site->url('formations')); ?>">Formations</a> › <?php echo e($training['title']); ?><?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    .training-layout { display: grid; grid-template-columns: 1fr 360px; gap: 40px; align-items: start; }
    .booking { position: sticky; top: 96px; background: #fff; border: 1px solid var(--line); border-top: 4px solid var(--orange); border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow); }
    .booking .price { font-family: var(--heading); font-size: 1.8rem; font-weight: 700; color: var(--navy); line-height: 1.1; }
    .facts { list-style: none; padding: 0; margin: 18px 0; display: grid; gap: 10px; font-size: .92rem; }
    .facts li { display: flex; justify-content: space-between; gap: 10px; border-bottom: 1px dashed var(--line); padding-bottom: 8px; }
    .facts b { color: var(--ink); }
    .timeline { list-style: none; padding: 0; margin: 0; border-left: 3px solid var(--line); }
    .timeline li { position: relative; padding: 0 0 22px 24px; }
    .timeline li::before { content: ''; position: absolute; left: -8px; top: 4px; width: 13px; height: 13px; border-radius: 50%; background: var(--orange); box-shadow: 0 0 0 3px #fff; }
    .timeline b { display: block; color: var(--navy); font-family: var(--heading); }
    .included { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; }
    .included div { background: var(--alt); border: 1px solid var(--line); border-radius: var(--radius-sm); padding: 14px; font-weight: 600; color: var(--ink); font-size: .92rem; }
    .included div::before { content: '✓ '; color: var(--success); }
    @media (max-width: 900px) { .training-layout { grid-template-columns: 1fr; } .booking { position: static; } }
<?php $__env->stopPush(); ?>

<?php $__env->startSection('page_head'); ?>
    <div class="training-head">
        <div>
            <div class="tags" style="margin-bottom: 14px;"><span class="tag tag-orange"><?php echo e($training['level']); ?></span><span class="tag">⏱ <?php echo e($training['duration']); ?></span><span class="tag">🗓 <?php echo e($training['schedule']); ?></span></div>
            <h1><?php echo e($training['icon']); ?> <?php echo e($training['title']); ?></h1>
            <p class="lead" style="margin: 0;"><?php echo e($training['summary']); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php ($sessions = collect($site->sessions())->where('slug', $training['slug'])); ?>

    <section class="section">
        <div class="wrap training-layout">
            <div>
                <h2>Ce que vous allez apprendre</h2>
                <ul class="bullets" style="font-size: 1rem;">
                    <?php $__currentLoopData = $training['points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($point); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <h2 class="mt-3">Programme</h2>
                <ol class="timeline">
                    <?php $__currentLoopData = $training['program']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><b><?php echo e($step['week']); ?></b><?php echo e($step['topic']); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>

                <h2 class="mt-2">Compris dans le prix</h2>
                <div class="included">
                    <?php $__currentLoopData = $training['included']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($item); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <h2 class="mt-3">Questions sur cette formation</h2>
                <?php $__currentLoopData = $site->faq()['Formations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <details class="faq" <?php if($loop->first): ?> open <?php endif; ?>><summary><?php echo e($item['q']); ?></summary><p><?php echo e($item['a']); ?></p></details>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <aside class="booking">
                <span class="muted small">À partir de</span>
                <div class="price"><?php echo e($site->money($training['price'])); ?></div>
                <?php if($training['installments'] > 1): ?>
                    <span class="tag tag-gold mt-1">ou <?php echo e($training['installments']); ?> × <?php echo e($site->money(ceil($training['price'] / $training['installments'] / 500) * 500)); ?></span>
                <?php endif; ?>
                <ul class="facts">
                    <li><span>Durée</span><b><?php echo e($training['duration']); ?></b></li>
                    <li><span>Rythme</span><b><?php echo e($training['schedule']); ?></b></li>
                    <li><span>Groupe</span><b>12 élèves max.</b></li>
                    <li><span>Prochaine rentrée</span><b><?php echo e($sessions->first()['start'] ?? 'Sur demande'); ?></b></li>
                </ul>
                <?php if($sessions->isNotEmpty() && $sessions->first()['left'] > 0): ?>
                    <p class="small" style="color: var(--orange-text); font-weight: 600;">🔥 Plus que <?php echo e($sessions->first()['left']); ?> places</p>
                <?php endif; ?>
                <a class="btn btn-primary btn-block" href="<?php echo e($site->url('inscription')); ?>?formation=<?php echo e($training['slug']); ?>">Réserver ma place</a>
                <a class="btn btn-ghost btn-block mt-1" href="<?php echo e($site->whatsappLink('Bonjour, j’ai une question sur la formation « '.$training['title'].' ».')); ?>" target="_blank" rel="noopener"><svg class="wa-ico"><use href="#wa"/></svg>Poser une question</a>
                <p class="muted small center mt-1" style="margin-bottom: 0;">Wave · Orange Money · MTN · Moov · Espèces</p>
            </aside>
        </div>
    </section>

    <section class="section section-alt">
        <div class="wrap">
            <h2>Autres formations</h2>
            <div class="grid grid-3 mt-2">
                <?php $__currentLoopData = collect($site->trainings())->where('slug', '!=', $training['slug'])->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherTraining): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('site.partials.training-card', ['training' => $otherTraining], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\atelier-ivoirien-cuisiniers\resources\views/site/formation.blade.php ENDPATH**/ ?>