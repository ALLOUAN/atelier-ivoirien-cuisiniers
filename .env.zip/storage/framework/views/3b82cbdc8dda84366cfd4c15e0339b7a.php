<?php $__env->startPush('styles'); ?>
    .dash { display: grid; grid-template-columns: 1.6fr 1fr; gap: 20px; }
    .chart { display: flex; align-items: flex-end; gap: 12px; height: 200px; padding-top: 10px; }
    .chart div { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 6px; height: 100%; justify-content: flex-end; font-size: .75rem; color: var(--muted); }
    .chart i { width: 100%; max-width: 44px; background: var(--navy-100); border-radius: 6px 6px 0 0; }
    .chart div:last-child i { background: var(--orange); }
    .chart div:last-child { color: var(--orange-text); font-weight: 700; }
    .split { display: grid; gap: 12px; }
    .split div { display: grid; grid-template-columns: 110px 1fr auto; gap: 10px; align-items: center; font-size: .88rem; }
    .split i { height: 10px; border-radius: 5px; background: var(--navy-100); overflow: hidden; }
    .split i::before { content: ''; display: block; height: 100%; width: var(--w); background: var(--navy); }
    .alert-list { display: grid; gap: 10px; }
    .alert { display: flex; gap: 10px; align-items: center; padding: 12px; border-radius: var(--radius-sm); font-size: .88rem; }
    .alert-warning { background: var(--warning-bg); color: var(--warning); }
    .alert-info { background: var(--navy-50); color: var(--navy); }
    @media (max-width: 1000px) { .dash { grid-template-columns: 1fr; } }
<?php $__env->stopPush(); ?>

<?php $__env->startSection('top_actions'); ?>
    <a class="btn btn-primary btn-sm" href="<?php echo e($site->url('gerant/caisse')); ?>">+ Nouvelle vente</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $dashboard = $site->dashboard();
        $peak = max(array_column($dashboard['week'], 'amount'));
        $cashTotal = array_sum($dashboard['cash_in']);
        $lowStock = collect($site->stock())->filter(fn (array $item): bool => $item['quantity'] < $item['minimum']);
        $balances = collect($site->clients())->sum(fn (array $client): int => $client['total'] - $client['paid']);
    ?>

    <div class="kpis">
        <div class="kpi dark"><span>Ventes du jour</span><b><?php echo e($site->money($dashboard['today'])); ?></b><span class="up">▲ <?php echo e($dashboard['change']); ?> % vs hier</span></div>
        <div class="kpi"><span>Commandes</span><b><?php echo e($dashboard['orders']); ?></b><span class="muted small">dont 9 livrées</span></div>
        <div class="kpi"><span>Inscriptions</span><b><?php echo e($dashboard['signups']); ?></b><span class="muted small">cette semaine : 11</span></div>
        <div class="kpi"><span>Reste à encaisser</span><b><?php echo e($site->money($balances)); ?></b><span class="muted small">versements élèves</span></div>
    </div>

    <div class="dash">
        <div class="panel">
            <h2>Ventes des 7 derniers jours</h2>
            <div class="chart">
                <?php $__currentLoopData = $dashboard['week']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div title="<?php echo e($site->money($day['amount'])); ?>"><span><?php echo e(round($day['amount'] / 1000)); ?>k</span><i style="height: <?php echo e(round($day['amount'] / $peak * 80)); ?>%"></i><?php echo e($day['day']); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="panel">
            <h2>Encaissements du jour</h2>
            <div class="split">
                <?php $__currentLoopData = $dashboard['cash_in']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method => $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><span><?php echo e($method); ?></span><i style="--w: <?php echo e(round($amount / $cashTotal * 100)); ?>%"></i><b style="color: var(--ink)"><?php echo e($site->money($amount)); ?></b></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="panel">
            <h2>Dernières opérations</h2>
            <div class="table-wrap" style="border: 0;">
                <table>
                    <thead><tr><th>Heure</th><th>Client</th><th>Détail</th><th>Moyen</th><th>Statut</th><th class="num">Montant</th></tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $dashboard['recent']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="muted"><?php echo e($operation['time']); ?></td>
                                <td><b style="color: var(--ink)"><?php echo e($operation['client']); ?></b></td>
                                <td><?php echo e($operation['label']); ?></td>
                                <td><?php echo e($operation['method']); ?></td>
                                <td><span class="<?php echo \Illuminate\Support\Arr::toCssClasses(['tag', 'tag-success' => in_array($operation['status'], ['Livrée', 'Payée']), 'tag-orange' => $operation['status'] === 'En livraison', 'tag-warning' => $operation['status'] === 'En préparation']); ?>"><?php echo e($operation['status']); ?></span></td>
                                <td class="num"><b style="color: var(--navy)"><?php echo e($site->money($operation['amount'])); ?></b></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div style="display: grid; gap: 20px; align-content: start;">
            <div class="panel">
                <h2>À surveiller</h2>
                <div class="alert-list">
                    <?php $__currentLoopData = $lowStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="alert alert-warning" href="<?php echo e($site->url('gerant/stock')); ?>">⚠️ <span><b><?php echo e($item['name']); ?></b> : <?php echo e($item['quantity']); ?> <?php echo e($item['unit']); ?> (min. <?php echo e($item['minimum']); ?>)</span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a class="alert alert-info" href="<?php echo e($site->url('gerant/clients')); ?>">🎓 <span><b>3 élèves</b> ont un versement à faire cette semaine</span></a>
                </div>
            </div>
            <div class="panel">
                <h2>Plats les plus vendus (mois)</h2>
                <ol style="margin: 0; padding-left: 20px; display: grid; gap: 8px; font-size: .92rem;">
                    <?php $__currentLoopData = $dashboard['best_sellers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><span style="display: flex; justify-content: space-between;"><span><?php echo e($dish['name']); ?></span><b style="color: var(--navy)"><?php echo e($dish['sold']); ?></b></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.gerant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\atelier-ivoirien-cuisiniers\resources\views/site/gerant/tableau-de-bord.blade.php ENDPATH**/ ?>