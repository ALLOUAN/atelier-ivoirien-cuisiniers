<?php $__env->startSection('page_head'); ?>
    <h1>Questions fréquentes</h1>
    <p class="lead" style="margin: 0;">Formations, paiement, commandes : les réponses aux questions qu’on nous pose le plus.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="narrow">
            <?php $__currentLoopData = $site->faq(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic => $questions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2 class="<?php echo \Illuminate\Support\Arr::toCssClasses(['mt-3' => ! $loop->first]); ?>" style="font-size: 1.3rem;"><?php echo e($topic); ?></h2>
                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <details class="faq" <?php if($loop->parent->first && $loop->first): ?> open <?php endif; ?>><summary><?php echo e($item['q']); ?></summary><p><?php echo e($item['a']); ?></p></details>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="card mt-3 center" style="background: var(--alt);">
                <h3>Vous ne trouvez pas votre réponse ?</h3>
                <p class="muted">Posez-nous la question directement, un membre de l’équipe vous répond.</p>
                <a class="btn btn-primary" style="align-self: center;" href="<?php echo e($site->whatsappLink('Bonjour, j’ai une question :')); ?>" target="_blank" rel="noopener"><svg class="wa-ico"><use href="#wa"/></svg>Poser ma question</a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\atelier-ivoirien-cuisiniers\resources\views/site/faq.blade.php ENDPATH**/ ?>