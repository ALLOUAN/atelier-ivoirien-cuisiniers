
<?php if (! $__env->hasRenderedOnce('6d77f0cc-3cb6-4abf-9fe3-91a029f5699b')): $__env->markAsRenderedOnce('6d77f0cc-3cb6-4abf-9fe3-91a029f5699b'); ?>
    <?php $__env->startPush('styles'); ?>
        .card-photo { position: relative; display: block; margin: -26px -26px 20px; aspect-ratio: 16 / 11; overflow: hidden; border-radius: var(--radius-lg) var(--radius-lg) 0 0; }
        .card.featured .card-photo { margin: -26px -26px 20px; }
        .card-photo img { width: 100%; height: 100%; object-fit: cover; display: block; transition: transform .8s var(--ease); }
        .card:hover .card-photo img { transform: scale(1.06); }
        .card-photo .icon-box { position: absolute; left: 18px; bottom: -24px; margin: 0; background: #fff; box-shadow: var(--shadow); border: 4px solid #fff; border-radius: 16px; width: 56px; height: 56px; font-size: 1.5rem; }
        .card-photo .duration { position: absolute; right: 12px; top: 12px; background: rgb(255 255 255 / .9); -webkit-backdrop-filter: blur(8px); backdrop-filter: blur(8px); color: var(--navy); font-size: .75rem; font-weight: 700; padding: 5px 11px; border-radius: var(--pill); box-shadow: var(--shadow-sm); }
        .card.featured::before { z-index: 2; }
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<article class="<?php echo \Illuminate\Support\Arr::toCssClasses(['card', 'hover', 'featured' => $training['featured']]); ?>" data-badge="Le plus demandé" data-category="<?php echo e($training['category']); ?>">
    <a class="card-photo" href="<?php echo e($site->trainingUrl($training['slug'])); ?>" tabindex="-1" style="overflow: visible;">
        <span style="display: block; height: 100%; overflow: hidden; border-radius: inherit;"><img src="<?php echo e($site->photo($training['image'])); ?>" alt="<?php echo e($training['title']); ?>" loading="lazy"></span>
        <span class="duration">⏱ <?php echo e($training['duration']); ?></span>
        <span class="icon-box" aria-hidden="true"><?php echo e($training['icon']); ?></span>
    </a>
    <h3 style="margin-top: 14px;"><a href="<?php echo e($site->trainingUrl($training['slug'])); ?>"><?php echo e($training['title']); ?></a></h3>
    <div class="tags" style="margin-bottom: 14px;"><span class="tag tag-orange"><?php echo e($training['level']); ?></span><span class="tag">🗓 <?php echo e($training['schedule']); ?></span></div>
    <ul class="bullets">
        <?php $__currentLoopData = $training['points']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($point); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="price-line">À partir de<b><?php echo e($site->money($training['price'])); ?></b><?php if($training['installments'] > 1): ?><span class="small">ou <?php echo e($training['installments']); ?> versements</span><?php endif; ?></div>
    <a class="btn <?php echo e($training['featured'] ? 'btn-primary' : 'btn-ghost'); ?> btn-sm btn-block mt-1" href="<?php echo e($site->trainingUrl($training['slug'])); ?>">Voir le programme</a>
</article>
<?php /**PATH C:\laragon\www\atelier-ivoirien-cuisiniers\resources\views/site/partials/training-card.blade.php ENDPATH**/ ?>